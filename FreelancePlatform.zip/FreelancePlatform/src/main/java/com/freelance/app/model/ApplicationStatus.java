package com.freelance.app.model;

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
