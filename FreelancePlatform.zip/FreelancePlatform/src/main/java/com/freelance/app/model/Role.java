package com.freelance.app.model;

public enum Role {
    FREELANCER,
    EMPLOYER
}
